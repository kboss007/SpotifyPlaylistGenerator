const ipv4 = "10.50.47.71"
const port = 3000;
const URL = `http://${ipv4}:${port}`
const Redirect = `${URL}/callback`
const Client_ID = "7f68c0ab15284d9a802201b5fe29e566"
const Client_Secret = "63cba930d5cb44d6902cfca02804b855"
const TOKEN = "https://accounts.spotify.com/api/token"

const express = require('express');
const path = require("path")
const querystring = require('querystring');
const cors = require('cors');
const axios = require('axios');
const bodyParser = require('body-parser');
const { type } = require('os');
const { Console } = require('console');

const app = express();


const Users = new Map();

const corsOptions = {
    origin: URL,
    optionsSuccessStatus: 200,
};

app.use(cors(corsOptions));
app.use(express.json())
app.use(bodyParser.json());
app.use(express.static('app/public'));

app.get("/", function(req, res){
    res.sendFile(path.join(__dirname, "app", "views", "start.html"))
});

app.get("/PlayListGen", function(req, res){
    res.sendFile(path.join(__dirname, "app", "views", "PlaylistGen.html"))
});
app.get("/Dashboard", function(req, res){
    res.sendFile(path.join(__dirname, "app", "views", "Dashboard.html")) 
});

app.get('/authorize', function(req, res) {
    let url = "https://accounts.spotify.com/authorize"
    url += "?client_id=" + Client_ID;
    url += "&response_type=code";
    url += "&redirect_uri=" + Redirect;
    url += "&state="+generateRandomString(16);
    url += "&show_dialog=true";
    url += "&scope=user-read-private user-read-email";
    res.redirect(url)
});


app.get('/callback', function(req, res) {
    let code = req.query.code || null;
    const tokenParams = {
      grant_type: 'authorization_code',
      code: code,
      client_id: Client_ID,
      client_secret: Client_Secret,
      redirect_uri: Redirect,
    };
    if(code != null){
        tokenExchange(tokenParams).then(function(d1){
            fetch('https://api.spotify.com/v1/me', {
                headers: {
                    'Authorization': `Bearer ${d1.access_token}`
                }
            }).then(function(response) {
                response.json().then(data => {
                    let user = Users.get(data.id);
                    if(user === undefined){
                        user = new User(data.id, data);
                        Users.set(data.id, user);
                    }
                    // console.log(data.id)
                    if(!user.HasAccessToken("user-read-private") || !user.HasAccessToken("user-read-email")){
                        user.addAccessToken("user-read-private",d1.access_token);
                        user.addAccessToken("user-read-email",d1.access_token);
                    }
                    
                    let cTokens = user.ChangeingTokens();
                    for (const key of user.getScopes()) {
                        if(cTokens.includes(key)){
                            user.addAccessToken(key,d1.access_token);
                            user.ToggleChangeingTokens([key]);
                        }
                    }
                    
                    let neededTokens = user.NeededAccessTokens();
                    if(neededTokens.length > 0){
                        let url = "https://accounts.spotify.com/authorize"
                        let scope = "";
                        for (let i = 0; i < neededTokens.length && i < 5; i++) {
                            scope += neededTokens.pop()+" ";
                        }
                        url += "?client_id=" + Client_ID;
                        url += "&response_type=code";
                        url += "&redirect_uri=" + Redirect;
                        url += "&state="+generateRandomString(16);
                        url += "&show_dialog=true";
                        url += "&scope=" + scope.slice(0, -1);
                        user.ToggleChangeingTokens((scope.slice(0, -1)).split(/\s+/));
                        res.redirect(url)
                    } else{
                        res.redirect(`http://10.50.47.71:3000/Dashboard?id=${user.id}`)
                    }
                })
            })
            .catch(error => console.error('Error fetching user profile:', error));
        });
    }       
});

app.get("/SearchArtists", async function(req, res){
    try {
        let ID = req.query.id || null;
        let artist = req.query.artist || null;
        let limit = req.query.lim || null;
        const result = await searchArtists(ID, artist, limit);
        res.json(result);
    } catch (error) {
        console.error('Error::', error.message);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

app.get("/GetUserProfile", async function(req, res){
    try{
        let ID = req.query.id || null;
        const result = await getUserProfile(ID);
        res.json(result);
    } catch (error) {
        console.error('Error::', error.message);
        res.status(500).json({ error: 'Internal Server Error' });
    }
})

app.get("/CurrentTrack", async function(req, res){
    try{
        let ID = req.query.id || null;
        const result = await getCurrentTrack(ID);
        const data = await result.json();
        res.json(data);
    } catch (error) {
        console.error('Error::', error.message);
        res.status(500).json({ error: 'Internal Server Error' });
    }
})

app.get("/AudioAnalysis", async function(req, res){
    try{
        let ID = req.query.id || null;
        getAudioAnalysis(ID).then(function(result){
            res.json(result);
        }).catch(function(error){
            console.log("Error:", error)
        })
        
    } catch (error) {
        console.error('Error::', error.message);
        res.status(500).json({ error: 'Internal Server Error' });
    }
})

app.post("/BuildPlayList", async function(req, res){
    const Info = req.body;
    const access_token = Users.get(Info.id).getAccessToken("playlist-modify-private");

    const playlist = await createPlaylist(Info)
    let user = Users.get(Info.id);
    let tracksToAdd = [];
    
    for (let g = 0; g < Info.artists.length; g++) {
        let tracks = new MinHeap();
        if(Info.buildType === "mood"){
            tracks = new MinHeap(async function(a, b){
                if(a == undefined || b == undefined){
                    return 0;
                }
                let trackInfo1 = await getTrackAudioInfo(user.getAccessToken("user-read-playback-state"),a.id, a.name);
                let trackInfo2 = await getTrackAudioInfo(user.getAccessToken("user-read-playback-state"),b.id, b.name);
                return (trackInfo1.energy - trackInfo2.energy);
            });
        }
        let Albums = await getArtistTopAlbums(access_token, Info.artists[g].artist.id, 50);
        
        for (let i = 0; i < Albums.length; i++) {
            const albumTracks = await getAlbumTracks(user.getAccessToken("user-library-read"), Albums[i].id)
            for (let j = 0; j < albumTracks.length; j++) {
                let audioInfo = await getTrackAudioInfo(user.getAccessToken("user-read-playback-state"), albumTracks[j].id, albumTracks[j].name)
                // console.log(albumTracks[j].id, albumTracks[j].name)
                // console.log(albumTracks[j], albumTracks[j])
                if(albumTracks[j] != undefined){
                    if(Info.buildType === "mood"){
                        if(user.light < 20000 && audioInfo.energy < 0.5){
                            tracks.add(albumTracks[j]);
                            console.log("1", albumTracks[j].name, audioInfo.energy)
                        } else if(user.light > 20000 && audioInfo.energy > 0.5){
                            tracks.add(albumTracks[j]);
                            console.log("2", albumTracks[j].name, audioInfo.energy)
                        }
                    } else{
                        tracks.add(albumTracks[j]);
                    }
                    console.log("Tracks Added To Big Heap", albumTracks[j].name)
                    
                }
            }
        }
        while(tracks.size() != Info.artists[g].amount){
            if(tracks.size() > Info.artists[g].amount){
                tracks.remove();
                console.log("Making Heap To Correct Size", tracks.size())
            } else{
                break;
            }
        }
        for (let i = 0; i < Info.artists[g].amount; i++) {
            tracksToAdd.push(tracks.remove());
        }
    }
    for (let i = 0; i < tracksToAdd.length; i++) {
        console.log(tracksToAdd[i])
        await addTrackToPlaylist(access_token, playlist.data.id, tracksToAdd[i].uri, tracksToAdd[i].name);
    }
    res.json({ message: 'Playlist Made', data: req.body });
})

app.post("/lightLevel", function(req, res){
    const requestData = req.body;
    const user = Users.get(req.body.id);
    user.light = requestData.lightLevel;
    // console.log("DATA: ",user.name, user.light);
})


app.listen(port, () => {
    console.log(`Server is listening at http://10.50.47.71:${port}`);
});

async function createPlaylist(Info){
    let access_token = Users.get(Info.id).getAccessToken("playlist-modify-private");
    let name = Info.name;
    if(name === ''){
        name = "A New Playlist"
    }
    const url = 'https://api.spotify.com/v1/me/playlists';
    const headers = {
        'Authorization': `Bearer ${access_token}`,
        'Content-Type': 'application/json',
    };
    const playlistData = {
        name: name,
        description: 'Just A Playlist',
        public: false,
    };
    const playlistId = await axios.post(url, playlistData, { headers }).catch(error => {
        console.error(`Error creating playlist: ${error.response.status}`);
        console.error(error.response.data);
    });
    return playlistId;
}

async function getAlbumTracks(accessToken, albumId) {
    const apiUrl = `https://api.spotify.com/v1/albums/${albumId}/tracks`;

    try {
        const response = await axios.get(apiUrl, {
            headers: {
                'Authorization': `Bearer ${accessToken}`,
            },
        });

        const tracks = response.data.items;
        const detailedTrackPromises = tracks.map(async track => {
            const trackResponse = await axios.get(`https://api.spotify.com/v1/tracks/${track.id}`, {
                headers: {
                    Authorization: `Bearer ${accessToken}`,
                },
            });
            return trackResponse.data;
        });

        const detailedTracks = await Promise.all(detailedTrackPromises);
        return detailedTracks;

    } catch (error) {
        console.error('Error getting album tracks:', error.response.data);
        return null;
    }
}

async function getArtistTopTracks(accessToken, artistId, amount, buildType="popularity"){
    const apiUrl = `https://api.spotify.com/v1/artists/${artistId}/top-tracks?market=US&limit=${amount}`;
    try {
        const response = await axios.get(apiUrl, {
            headers: {
                'Authorization': `Bearer ${accessToken}`,
            },
        });
        const topTracks = response.data.tracks;
        // console.log('Top Tracks:', topTracks);
        return topTracks;
    } catch (error) {
        console.error('Error getting top tracks:', error.response.data);
        return null;
    }
}

async function getArtistTopAlbums(accessToken, artistId, amount, retryCount=0){
    // console.log("GETTING ALBUM AT", Date.now())
    const apiUrl = `https://api.spotify.com/v1/artists/${artistId}/albums`;
    try {
        const response = await axios.get(apiUrl, {
            headers: {
                'Authorization': `Bearer ${accessToken}`,
            },
            params: {
                limit: amount,
            },
        });
        const topTracks = response.data.items;
        return topTracks;
    } catch (error) {
        if (error.response && error.response.status === 429 && retryCount < 3) {
            const waitTime = Math.pow(2, retryCount) * 1000;
            await new Promise(resolve => setTimeout(resolve, waitTime));

            console.error("ERROR: ", error );
            console.error('Error getting top Albums Retrying');
            return getArtistTopAlbums(accessToken, artistId, amount, retryCount + 10);
        } else {
            console.error('Could Not Get Top Albums:', error.response.data);
            return null;
        }
    }
}

async function evaluateLightLevel(value){

}

async function addTrackToPlaylist(accessToken, playlistId, trackUri, trackName) {
    const apiUrl = `https://api.spotify.com/v1/playlists/${playlistId}/tracks`;
  
    const headers = {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    };
  
    try {
      const response = await axios.post(
        apiUrl,
        {
          uris: [trackUri],
        },
        { headers }
      );
  
    //   console.log('Track added to playlist successfully:', response.data);
      console.log('Track added to playlist successfully:', trackName);
    } catch (error) {
      console.error('Error adding track to playlist:', error.response.data);
    }
  }


async function tokenExchange(tokenParams){
    try {
        const tokenResponse = await axios.post(TOKEN, querystring.stringify(tokenParams), {
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded',
            },
        })
        const accessToken = tokenResponse.data.access_token;
        return { access_token: accessToken };

      } catch (error) {
        console.error('Error in /callback:', error.message);
        return { error: 'Internal Server Error' };
    }
}

function generateRandomString(length) {
    const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    let randomString = "";
  
    for (let i = 0; i < length; i++) {
      const randomIndex = Math.floor(Math.random() * charset.length);
      randomString += charset.charAt(randomIndex);
    }
    return randomString;
}

async function getUserProfile(id) {
    const response = await fetch("https://api.spotify.com/v1/me", {
        headers: {
        'Authorization': `Bearer ${Users.get(id).getAccessToken("user-read-private")}`,
        },
    });

    if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
    }

    const data = await response.json();
    return data;
}

const getCurrentTrack = debounceAsync(async (id) => {
    // console.log("getCurrentTrack", Date.now())
    const response = await fetch("https://api.spotify.com/v1/me/player/currently-playing", {
        headers: {
            'Authorization': `Bearer ${Users.get(id).getAccessToken("user-read-playback-state")}`,
        },
    });
    
    if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
    }

    return response;
}, 1000)

const getAudioAnalysis = debounceAsync(async (id) => {
    // console.log("getAudioAnalysis", Date.now())
    let temp = await getCurrentTrack(id);
    let currentTrack = await temp.json();
    const url = `${"https://api.spotify.com/v1/audio-analysis"}/${currentTrack.item.id}`;
  
    const response = await fetch(url, {
      headers: {
        'Authorization': `Bearer ${Users.get(id).getAccessToken("user-read-playback-state")}`,
      },
    });
  
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`, currentTrack);
    }
  
    
    const data = await response.json();
    return data;
},100)


async function searchArtists(id, name, limit) {
    const SPOTIFY_API_URL = 'https://api.spotify.com/v1/search';
    const headers = {
      'Authorization': `Bearer ${Users.get(id).getAccessToken("user-read-email")}`,
    };
  
    const params = new URLSearchParams({
      q: name,
      type: 'artist',
      limit: limit,
    });
  
    const url = `${SPOTIFY_API_URL}?${params}`;
    const response = await axios.get(url, { headers });
  
    if (!response.data.artists) {
      throw new Error('No artists found.');
    }

    return response.data.artists.items;
}

async function getTrackAudioInfo(accessToken, trackId, trackName) {
    try {
        // console.log(Date.now())
        const apiUrl = `https://api.spotify.com/v1/audio-features/${trackId}`;
        const response = await fetch(apiUrl, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': 'application/json'
            },
        });

        if (response.status === 429) {
            // console.error('Rate limit exceeded. Waiting 1 second before retrying...');
            await new Promise(resolve => setTimeout(resolve, 1000));
            return getTrackAudioInfo(accessToken, trackId);
        }

        if (response.status === 408) {
            console.error('Connect timeout. Retrying...');
            return getTrackAudioInfo(accessToken, trackId);
        }

        if (response.status === 503) {
            console.error('Server is not ready to handle the request. Waiting 1 second before retrying...');
            await new Promise(resolve => setTimeout(resolve, 1000));
            return getTrackAudioInfo(accessToken, trackId);
        }

        if (response.status === 502) {
            console.error('Received invalid response from upstream server. Retrying...');
            return getTrackAudioInfo(accessToken, trackId);
        }

        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }

        const data = await response.json();
        console.log("ENERGY", trackName, data.energy)
        return data;
    } catch (error) {
        console.error('Error:', error.message);
        if(error.message === 'fetch failed'){
            // await new Promise(resolve => setTimeout(resolve, 1000));
            return getTrackAudioInfo(accessToken, trackId);
        }
        throw error;
    }
}

function debounce(func, delay) {
    let timer;
    return function() {
      clearTimeout(timer);
      timer = setTimeout(() => {
        func.apply(this, arguments);
      }, delay);
    };
}

function debounceAsync(asyncFunc, delay) {
    let timer;
    return function () {
        clearTimeout(timer);
        return new Promise((resolve, reject) => {
            timer = setTimeout(async () => {
                try {
                    const result = await asyncFunc.apply(this, arguments);
                    resolve(result);
                } catch (error) {
                    reject(error);
                }
            }, delay);
        });
    };
}

class User {
    #ID;
    #UserProfile;
    #light
    #accessTokens = new Map([
        ["ugc-image-upload", undefined],
        ["user-read-playback-state", undefined],
        ["user-modify-playback-state", undefined],
        ["user-read-currently-playing", undefined],
        ["app-remote-control", undefined],
        ["streaming", undefined],
        ["playlist-read-private", undefined],
        ["playlist-read-collaborative", undefined],
        ["playlist-modify-private", undefined],
        ["playlist-modify-public", undefined],
        ["user-follow-modify", undefined],
        ["user-follow-read", undefined],
        ["user-read-playback-position", undefined],
        ["user-top-read", undefined],
        ["user-read-recently-played", undefined],
        ["user-library-modify", undefined],
        ["user-library-read", undefined],
        ["user-read-email", undefined],
        ["user-read-private", undefined]
    ]);
    #refreshTokens = new Map([
        ["ugc-image-upload", undefined],
        ["user-read-playback-state", undefined],
        ["user-modify-playback-state", undefined],
        ["user-read-currently-playing", undefined],
        ["app-remote-control", undefined],
        ["streaming", undefined],
        ["playlist-read-private", undefined],
        ["playlist-read-collaborative", undefined],
        ["playlist-modify-private", undefined],
        ["playlist-modify-public", undefined],
        ["user-follow-modify", undefined],
        ["user-follow-read", undefined],
        ["user-read-playback-position", undefined],
        ["user-top-read", undefined],
        ["user-read-recently-played", undefined],
        ["user-library-modify", undefined],
        ["user-library-read", undefined],
        ["user-read-email", undefined],
        ["user-read-private", undefined]
    ]);
    #changingTokens = new Map([
        ["ugc-image-upload", false],
        ["user-read-playback-state", false],
        ["user-modify-playback-state", false],
        ["user-read-currently-playing", false],
        ["app-remote-control", false],
        ["streaming", false],
        ["playlist-read-private", false],
        ["playlist-read-collaborative", false],
        ["playlist-modify-private", false],
        ["playlist-modify-public", false],
        ["user-follow-modify", false],
        ["user-follow-read", false],
        ["user-read-playback-position", false],
        ["user-top-read", false],
        ["user-read-recently-played", false],
        ["user-library-modify", false],
        ["user-library-read", false],
        ["user-read-email", false],
        ["user-read-private", false]
    ]);
    constructor(id, UserProfile){
        this.#ID = id;
        this.#UserProfile = UserProfile;
    }

    get id(){
        return this.#ID;
    }
    get name(){
        return this.#UserProfile.display_name;
    }
    get light(){
        return this.#light;
    }
    set light(n){
        this.#light = n;
    }

    addAccessToken(scope,token){
        if(!(this.#accessTokens.has(scope))){
            throw new Error("Invalid Scope:: "+scope)
        }
        this.#accessTokens.set(scope, token);
    }
    addRefreshToken(scope,token){
        if(!(this.#refreshTokens.has(scope))){
            throw new Error("Invalid Scope: "+scope)
        }
        this.#refreshTokens.set(scope, token);
    }
    getAccessToken(key){
        return this.#accessTokens.get(key);
    }
    getRefreshToken(key){
        return this.#refreshTokens.get(key);
    }
    HasAccessToken(scope){
        if(this.#accessTokens.get(scope) != undefined){
            return true;
        }
        return false;
    }
    TokenChanging(scope){
        return this.#changingTokens.get(scope);
    }
    getScopes(){
        let rtn = new Array();
        for (const key of this.#changingTokens.keys()) {
            rtn.push(key)
        }
        return rtn;
    }
    ChangeingTokens(){
        let rtn = new Array();
        for (const key of this.#changingTokens.keys()) {
            if(this.#changingTokens.get(key)){
                rtn.push(key)
            }
        }
        return rtn;
    }
    ToggleChangeingTokens(scope){
        if(!(typeof(scope) === typeof(new Array()))){
            throw new Error("Paramter must be an Array")
        }
        for (let i = 0; i < scope.length; i++) {
            this.#changingTokens.set(scope[i], !this.#changingTokens.get(scope[i]));
        }
    }
    NeededAccessTokens(){
        let rtn = new Array();
        for (const key of this.#accessTokens.keys()) {
            if(this.#accessTokens.get(key) === undefined){
                rtn.push(key)
            }
        }
        return rtn;
    }
    NeededRefreshTokens(){
        let rtn = new Array();
        for (const key of this.#refreshTokens.keys()) {
            if(this.#refreshTokens.get(key) === undefined){
                rtn.push(key)
            }
        }
        return rtn;
    }
}

class MinHeap {
    #data
    constructor(comparator = async function (a, b) {
        //console.log("COMPARE A", a)
        if(a == undefined || b == undefined){
            return 0;
        }
        return a.popularity - b.popularity
        }){
        this.#data = [];
        this.comparator = comparator;
    }


    isEmpty() {
        return this.#data.length == 0
    }

    async add(num) {
        this.#data.push(num)
        // console.log("DATA", this.#data[this.#data.length-1].name, this.#data.length);
        await this.heapifyUp(this.#data.length-1)
    }

    async heapifyUp(index) {
        if( index <= 0 ){
            return
        }
        let parent = Math.floor((index-1) / 2)
        const compare = await this.comparator(this.#data[parent], this.#data[index]);
        if( compare < 0) {
            let temp = this.#data[parent]
            this.#data[parent] = this.#data[index]
            this.#data[index] = temp
            this.heapifyUp(parent)
        }
    }

    remove() {
        if(this.#data.length == 0){
            return null
        }
        // console.log("REMOVING")
        let head = this.#data[0]
        this.#data[0] =  this.#data.pop()
        this.heapifyDown(0)
        return head
    }

    heapifyDown(index) {
        if(index >= this.#data.length){
            return
        }

        let children = [index * 2 + 1, index * 2 + 2]

        let minimum = index;

        for (let i = 0; i < children.length; i++) {
            let child = children[i]
            if (child < this.#data.length) {
                let compare = this.comparator(this.#data[minimum], this.#data[child])
                if (compare > 0){
                    minimum = child
                }
            }
        }

        if(minimum != index){
            let temp = this.#data[minimum]
            this.#data[minimum] = this.#data[index]
            this.#data[index] = temp
            this.heapifyDown(minimum)
        }
    }

    size(){
        return this.#data.length;
    }
}