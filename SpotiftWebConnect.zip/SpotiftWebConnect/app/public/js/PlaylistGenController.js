let ID = null;
let ARTISTS = new Array();
let PlaylistGenForm = null;
let AddedArtistsElements = null;
let AddArtistButton = null;
let FocusedTextBox = null;
let ProfilePicCt = null;
let SoundVisCanvas = null;
let AlbumPicCt = null;
let CurrentTrack = null;
let popularityToggle = null
let popularityLabel = null
let moodToggle = null
let moodLabel = null;
let buildButton = null;
let PlaylistNameInput = null;
let loadingScreen = null

function init(){
  const queryParams = new URLSearchParams(window.location.search);
  ID = queryParams.get("id")
  PlaylistGenForm = document.getElementById("PlaylistGenForm");
  AddedArtistsElements = document.getElementsByClassName("AddedArtist");
  AddArtistButton = document.getElementById("AddArtistButton");
  AddedArtistCt = document.getElementById("AddedArtistCt");
  ProfilePicCt = document.getElementById("ProfilePicCt");
  SoundVisCanvas = document.getElementById("SoundVisCanvas");
  AlbumPicCt = document.getElementById("AlbumPicCt");
  PlaylistNameInput = document.getElementById("PlaylistName")
  loadingScreen = document.getElementsByClassName("loadingScreen")[0];

  let inputs = PlaylistGenForm.getElementsByTagName("input");
  let labels = PlaylistGenForm.getElementsByTagName("label");
  for (let i = 0; i < inputs.length; i++) {
    if(inputs[i].type === "radio"){
      if(inputs[i].value === "popularity"){
        popularityToggle = inputs[i];
      }
      if(inputs[i].value === "mood"){
        moodToggle = inputs[i];
      }
    }
    if(inputs[i].type === "submit"){
      buildButton = inputs[i];
    }
  }
  for (let i = 0; i < labels.length; i++) {
    if(labels[i].htmlFor === "popularity"){
      popularityLabel = labels[i];
    }
    if(labels[i].htmlFor === "mood"){
      moodLabel = labels[i];
    }
  }

  document.body.addEventListener("keydown", function(e){
    if(e.key === 'c'){
      let artist = new Array();
      let addedArtist = AddedArtistCt.getElementsByClassName("AddedArtist")

      for (let i = 0; i < addedArtist.length; i++) {
        const element = {
          artist: ARTISTS[i],
          amount: addedArtist[i].getElementsByTagName("input")[1].value,
        }
        artist.push(element);
      }

      let postData = {
        id:ID,
        name: PlaylistNameInput.value,
        artists: artist,
        buildType: "popularity",
        light: null,
      }
      if(moodToggle.checked){
        postData.buildType = "mood";
      }
      console.log(postData)
      }
  })



  popularityLabel.addEventListener("click", function(){
    popularityToggle.checked = true;
  })
  moodLabel.addEventListener("click", function(){
    moodToggle.checked = true;
  })
  popularityLabel.parentNode.addEventListener("click", function(){
    let children = popularityLabel.parentNode.children;
    for (let i = 0; i < children.length; i++) {
      if(children[i].type === "radio"){
        if(children[i].checked){
          if(children[i].value === "popularity"){
            popularityLabel.classList.remove("inputNotToggled")
            popularityLabel.classList.add("inputToggled")
          } else{
            moodLabel.classList.remove("inputNotToggled")
            moodLabel.classList.add("inputToggled")
          }
        } else{
          if(children[i].value === "popularity"){
            popularityLabel.classList.remove("inputToggled")
            popularityLabel.classList.add("inputNotToggled")
          } else{
            moodLabel.classList.remove("inputToggled")
            moodLabel.classList.add("inputNotToggled")
          }
        }
      }
    }
  })
  buildButton.addEventListener("click", function(e){
    e.preventDefault();
    let artist = new Array();
    let addedArtist = AddedArtistCt.getElementsByClassName("AddedArtist")

    for (let i = 0; i < addedArtist.length; i++) {
      const element = {
        artist: ARTISTS[i],
        amount: addedArtist[i].getElementsByTagName("input")[1].value,
      }
      artist.push(element);
    }

    let postData = {
      id:ID,
      name: PlaylistNameInput.value,
      artists: artist,
      buildType: "popularity",
      light: null,
    }
    if(moodToggle.checked){
      postData.buildType = "mood";
    }
    console.log(postData)
    if((artist.length > 0)){
      const Building = fetch(`http://10.50.47.71:3000/BuildPlayList`,{
        method: "POST",
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(postData),
      })
      loadingScreen.style.display = 'flex'
      Building.then(function(data){
        loadingScreen.style.display = 'none'
      })
    } else{
      alert("Must Have At Least One Artist")
    }
  })

  fetch(`http://10.50.47.71:3000/GetUserProfile?id=${ID}`).then(function(d1){
    try {
      d1.json().then(function(data){
        if (data.images && data.images.length > 0) {
          if(data.images[1].url != undefined){
            ProfilePicCt.src = data.images[1].url;
          } else{
            ProfilePicCt.src = data.images[0].url;
          }
        } else {
          console.log('No profile picture available.');
        } 
      })
    } catch (error) {
      console.error('Error:', error.message);
    }
  })

  // setInterval(updateCurrentTrack, 100)

  for (let i = 0; i < AddedArtistsElements.length; i++) {
    const artistName = AddedArtistsElements[i].getElementsByTagName("input")[0];
    const artistSongAmount = AddedArtistsElements[i].getElementsByTagName("input")[1];
  }




  AddArtistButton.addEventListener('click', function(event) {
      event.preventDefault();
      const newAddedArtist = document.createElement("div");
      const divCt = document.createElement("div");
      const nameInput = document.createElement("input")
      const autoFillList = document.createElement("div")
      const numberInput = document.createElement("input")
      const deleteButton = document.createElement("button")
      deleteButton.textContent = "Delete"
      deleteButton.addEventListener('click', function(e){
          e.preventDefault();
          AddedArtistCt.removeChild(newAddedArtist)
          for (let i = 0; i < ARTISTS.length; i++) {
            if(ARTISTS[i].name === nameInput.value){
              ARTISTS.splice(ARTISTS.indexOf(ARTISTS[i]), 1)
            }
          }
      })
      nameInput.addEventListener("focusin", function(){
        FocusedTextBox = nameInput;
      })
      nameInput.addEventListener("focusout", function(){
        if(FocusedTextBox === nameInput){
          FocusedTextBox = null;
        }
      })
      nameInput.addEventListener("keyup", function(e){
        while(autoFillList.firstChild){
          autoFillList.removeChild(autoFillList.firstChild);
        }
        if(nameInput.value == ""){
          return;
        }
        let artists = new Array();
        let limit = 10;
        if(nameInput.value.length < 0){
          return;
        }
        fetch(`http://10.50.47.71:3000/SearchArtists?id=${ID}&artist=${nameInput.value}&lim=${limit}`).then(async function(d1){
           await d1.json().then(function(data){
            for (let i = 0; i < limit; i++) {
              artists.push(data[i])
            }
            SetSuggestionList(autoFillList, artists, limit);
          }); 
        }).catch(function(error){
          console.error('Error:', error.message);
        });
      })
      nameInput.name = "ArtistName";
      nameInput.type = "text";
      numberInput.name = "AmountofSongs";
      numberInput.type = "number"
      nameInput.classList.add("AddedArtistName")
      newAddedArtist.classList.add("AddedArtist")
      deleteButton.classList.add("DeleteArtist");
      numberInput.classList.add("AddedArtistAmount");
      divCt.appendChild(nameInput);
      divCt.appendChild(autoFillList);
      newAddedArtist.appendChild(divCt);
      newAddedArtist.appendChild(numberInput);
      newAddedArtist.appendChild(deleteButton)
      AddedArtistCt.insertBefore(newAddedArtist, AddArtistButton)
  });
}
async function getCurrentTrack(){
  console.log("getCurrentTrack")
  await fetch(`http://10.50.47.71:3000/CurrentTrack?id=${ID}`).then(async function(d1){
    await d1.json().then(function(data){
      CurrentTrack = data;
    }).catch(function(error){
      console.error('Error fetching current track:', error);
    })
  }).catch(function(error){
    console.error('Error fetching current track:', error);
  })
}
async function updateCurrentTrack(){
  await getCurrentTrack();
  await AudioAnalysis();
  // console.log(CurrentTrack)
  if (CurrentTrack.item.album.images && CurrentTrack.item.album.images.length > 0) {
    if(CurrentTrack.item.album.images[1].url != undefined){
      AlbumPicCt.src = CurrentTrack.item.album.images[1].url;
    } else{
      AlbumPicCt.src = CurrentTrack.item.album.images[0].url;
    }
  } else {
    console.log('No profile picture available.');
  }
}

async function AudioAnalysis(){
  console.log("AudioAnalysis")
  await fetch(`http://10.50.47.71:3000/AudioAnalysis?id=${ID}`).then(async function(d1){
    await d1.json().then(function(data){
      console.log(data)
      // console.log(CurrentTrack.progress_ms)
    }).catch(function(error){
      console.error('Error:', error.message);
    })
  }).catch(error => {
    console.error('Error:', error.message);
  })
}


function SetSuggestionList(ct, artists, limit){
  for (let i = 0; i < limit & ct.childElementCount < limit; i++) {
    const CT = document.createElement("div");
    const artistImage = document.createElement("img");
    const nameCt = document.createElement("div");
    const artistName = document.createElement("p");

    artistName.textContent = artists[i].name;
    artistImage.src = artists[i].images[0].url;

    CT.classList.add("ArtistSuggestion")
    CT.appendChild(artistImage);
    CT.appendChild(nameCt);
    nameCt.appendChild(artistName);
    ct.appendChild(CT);

    CT.addEventListener("click", function(e){
      let input = ct.parentNode.firstElementChild;
      input.value = CT.getElementsByTagName("p")[0].textContent;
      ARTISTS.push(artists[i])
      while(ct.firstChild){
        ct.removeChild(ct.firstChild);
      }
    })
  }
}
window.onload = init;