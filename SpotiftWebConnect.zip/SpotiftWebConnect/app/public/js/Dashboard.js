let NavigateToPlayListGen = null
let ID = null;
function init(){
    const queryParams = new URLSearchParams(window.location.search);
    ID = queryParams.get("id")
    NavigateToPlayListGen = document.getElementById("GoToPlayListGen")
    NavigateToPlayListGen.addEventListener("click", function(e){
        e.preventDefault();
        window.location.href = `http://${address.ipv4}:${address.port}/PlayListGen?id=${ID}`
    })
}
window.onload = init;