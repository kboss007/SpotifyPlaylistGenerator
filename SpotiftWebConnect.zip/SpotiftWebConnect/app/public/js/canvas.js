const SoundVisCanvas = document.getElementById("SoundVisCanvas");
const audioContext = new (window.AudioContext || window.webkitAudioContext)();
const analyser = audioContext.createAnalyser();
const canvasContext = SoundVisCanvas.getContext("2d");
import { AudioAnalysis } from './PlaylistGenController.js'; // Adjust the path as needed

audioContext.resume().then(() => {
    // Your code to initialize audio playback (e.g., from Spotify or any source)
    // This can involve fetching audio data, creating an audio source, and connecting it to the analyser node.
    
    

    // For a basic example, let's create a dummy audio buffer:
    const audioBuffer = audioContext.createBuffer(1, 44100 * 10, 44100);
    const audioSource = audioContext.createBufferSource();
    audioSource.buffer = audioBuffer;
    audioSource.connect(analyser);
    audioSource.start();

    // Connect the analyser to the audio context's destination (e.g., speakers)
    analyser.connect(audioContext.destination);
});

analyser.fftSize = 256;
const bufferLength = analyser.frequencyBinCount;
const dataArray = new Uint8Array(bufferLength);

function draw() {
    analyser.getByteFrequencyData(dataArray);

    canvasContext.clearRect(0, 0, SoundVisCanvas.width, SoundVisCanvas.height);

    const barWidth = (SoundVisCanvas.width / bufferLength) * 2;
    let barHeight;
    let x = 0;

    for (let i = 0; i < bufferLength; i++) {
        barHeight = dataArray[i] * 2;

        canvasContext.fillStyle = `rgb(${barHeight + 100},50,50)`;
        canvasContext.fillRect(x, SoundVisCanvas.height - barHeight / 2, barWidth, barHeight);

        x += barWidth + 1;
    }

    requestAnimationFrame(draw);
}

draw();
