package edu.ncssm.kboss.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private WebView mywebView;
    private SensorManager sensorManager;
    private Sensor lightSensor;
    private float lightLevel;
    private String dataId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mywebView = findViewById(R.id.webview);
        mywebView.setWebViewClient(new WebViewClient());
        WebSettings webSettings = mywebView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        // Initialize the SensorManager and LightSensor
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);

        // displays a website on the screen
        mywebView.loadUrl("http://10.50.47.71:3000/");

        if (lightSensor != null) {
            SensorEventListener lightSensorListener = new SensorEventListener() {
                @Override
                public void onSensorChanged(SensorEvent event) {
                    // Handle changes in ambient light level here
                    lightLevel = event.values[0];


                    // Call the method to send data to server
                    retrieveDataFromServer();
                    sendDataToServer(lightLevel);

                }

                @Override
                public void onAccuracyChanged(Sensor sensor, int accuracy) {
                    // This method is not usually used for the ambient light sensor.
                }
            };

            sensorManager.registerListener(lightSensorListener, lightSensor, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

// ...

    private void retrieveDataFromServer() {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    // Specify the URL to retrieve data from
                    URL url = new URL("http://10.50.47.71:3000/"); // Replace with your actual endpoint
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("GET");

                    int responseCode = conn.getResponseCode();
                    if (responseCode == HttpURLConnection.HTTP_OK) {
                        // Read the response from the server
                        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                        StringBuilder response = new StringBuilder();
                        String line;
                        while ((line = reader.readLine()) != null) {
                            response.append(line);
                        }
                        reader.close();

                        // Parse the JSON response to get data.id
                        String jsonResponse = response.toString();
                        JSONObject jsonObject = new JSONObject(jsonResponse);
                        dataId = jsonObject.getString("id"); // Replace "id" with the actual key in your JSON response
                        dataId = dataId.replace("\\", "");

                        // Now, you have the data.id, and you can use it as needed
                        Log.d("Data ID", dataId);
                    } else {
                        // Handle the error
                        Log.e("HTTP Error", "Response Code: " + responseCode);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        thread.start();
    }

    // Method to send data to the server
    private void sendDataToServer(float lightData) {
        mywebView.evaluateJavascript("(function() { return window.location.href; })();", new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String url) {
                try {
                    // Extract the ID from the URL
                    Uri parsedUrl = Uri.parse(URLDecoder.decode(url, "UTF-8"));
                    dataId = parsedUrl.getQueryParameter("id"); // Assuming 'id' is the query param name
                    dataId = dataId.replace("\\", "").replace("\"", "").trim();

                    Thread thread = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                URL serverUrl = new URL("http://10.50.47.71:3000/lightlevel");
                                HttpURLConnection conn = (HttpURLConnection) serverUrl.openConnection();
                                conn.setRequestMethod("POST");
                                conn.setRequestProperty("Content-Type", "application/json");
                                conn.setDoOutput(true);

                                JSONObject jsonObject = new JSONObject();
                                jsonObject.put("lightLevel", lightData);
                                jsonObject.put("id", dataId);

                                String postData = jsonObject.toString();
                                Log.d("JSON Data", postData);

                                OutputStream os = conn.getOutputStream();
                                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
                                writer.write(postData);
                                writer.flush();
                                writer.close();
                                os.close();

                                int responseCode = conn.getResponseCode();
                                // Handle the response code as needed
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
                    thread.start();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }




}

